x = 3;
y = 5;

switch (y){
    case 0:
        z = 3;
        break;
    case 1:
        z = 56;
        break;
    case 3:
        z = 209;
        break;
    case 7:
        z = 1;
        break;
    default:
        z = 0;
        break;
}